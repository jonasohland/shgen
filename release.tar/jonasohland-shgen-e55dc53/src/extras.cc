#include "extras.h"


void add_templated_accessor(const shgen_config& config,
                            std::ostream& headerfile)
{
}
